const db = require('../db')

class apiController{

async getUsers (req, res){
    try{
       
    }catch(e){
     
    }
} 
async getPosts (req, res){
    try{
     
   
    } catch(e){
        
    }
    
}


async getCommentsByPost (req, res){
    try{
     
    } catch(e){
        console.log(e)
    }
    
}

}


module.exports = new apiController()
