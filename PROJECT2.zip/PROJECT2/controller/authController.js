const db = require('../db')


class AuthController {
    async registration (req, res) {
        try{
           console.log(req.body);
           console.log(req.body.email);
        } catch(e) {
           
        }
    }
    async login (req, res) {
        try{
          
            
        }
        catch (e){
        
        }
    }

  

    

}

module.exports = new AuthController()

